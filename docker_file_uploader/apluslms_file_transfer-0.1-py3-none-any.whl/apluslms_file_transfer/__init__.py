FILE_TYPE1 = ['yaml', 'html']  # mtime of index.suffix can indicate whether it is a newer version
